# Importar modulos para importrar y leer archivos cvs
import csv
import os 

# Definir el path para leer el archivo csv 
csvpath = os.path.join("Resources","election_data.csv")

#Inicializacion de contadores 
counter = 0
votos_totales = 0
greatest_votos = 0

#Crear listas que contendran datos para imprimir (listas resumen)
candidatos = []
votos = []

#Leer el archivo y obtener datos requeridos para la impresion de la informacion requerida 
with open(csvpath,'r') as csvfile:
    
    csvreader = csv.reader(csvfile, delimiter = ",")
    
    # Obtener el header 
    header = next(csvreader) 
    
    if header != None: 
        # llenado de listas resumen
        for row in csvreader:
            row_value = row[2]
                        
            if len(candidatos) == 0:
                candidatos.append(row_value)
                votos.append(1)
                
            else:
                if row_value in candidatos:
                    indx = candidatos.index(row_value)
                    counter = votos[indx]
                    new_votes = counter + 1
                    votos[indx] = new_votes
                else:
                    candidatos.append(row_value)
                    votos.append(1)
                
#Calculo de votos totales                
for vot in votos:
    votos_totales = votos_totales + vot


#Impresion del total de votos entre todos los candidatos 
print("----------------------------- \n")
print("Election Results \n")
print("----------------------------- \n")
print(f"Total Votes:  {votos_totales} \n")
print("----------------------------- \n")

#Crer un archivo de texto con los resulatdos 
text_file = open("Output_PyPoll.txt", "w")
text_file.write("Election Results \n")
text_file.write("----------------------------- \n")
text_file.write(f"Total Votes:  {votos_totales} \n")
text_file.write("----------------------------- \n")


for cand_imprimir in candidatos:
    #Calculo del porcentaje de votos que el candidato obtuvo 
    x = candidatos.index(cand_imprimir)
    percentage = str(round((votos[x]/votos_totales)*100,3))

    #Imprimir Nombre candidato, su porcentaje, total de votos 
    print(f"{cand_imprimir}: {percentage}% ({votos[x]}) \n")
    text_file.write(f"{cand_imprimir}: {percentage}% ({votos[x]}) \n")
    
    #Obtener el ganador de las elecciones
    if votos[x] >= greatest_votos:
        greatest_votos = votos[x]
        winner = cand_imprimir

#Imprimir el ganador     
print("----------------------------- \n")
print(f"Winner:  {winner}")

text_file.write("----------------------------- \n")
text_file.write(f"Winner:  {winner}")

text_file.close()


