# Importar modulos para importrar y leer archivos cvs
import csv
import os 

# Definir el path para leer el archivo csv 
csvpath = os.path.join("Resources","budget_data.csv")

#Inicializacion de contadores 
row_counter = 0
row_sum = 0
profit_increase = 0
increase_month = "Ene-10" 
profit_decrease = 0
decrease_month = "Ene-10"


#Leer el archivo y obtener datos requeridos para la impresiond de la informacion requerida 
with open(csvpath,'r') as csvfile:
    
    csvreader = csv.reader(csvfile, delimiter = ",")
    
    # Obtener el header 
    header = next(csvreader) 
    
    if header != None: 
        for row in csvreader:
            row_counter += 1
            row_value = int(row[1])
            row_sum = row_sum + row_value
            
            if row_value > profit_increase:
                profit_increase = row_value
                increase_month = row[0]
            elif row_value < profit_decrease:
                profit_decrease = row_value
                decrease_month = row[0]

# Promedio de los datos
media = round(row_sum/row_counter,2)

# Impresion de los datos 

print(f"Total months:  {row_counter}")
print(f"Total:  ${row_sum}")
print(f"Average change:  ${media}")
print(f"Greatest increase in profits:  {increase_month}  $({profit_increase})")
print(f"Greatest decrease in profits:  {decrease_month}  $({profit_decrease})")

#Crer un archivo de texto con los resulatdos 
text_file = open("Output_PyBank.txt", "w")

text_file.write(f"Total months:  {row_counter} \n")
text_file.write(f"Total:  ${row_sum} \n")
text_file.write(f"Average change:  ${media} \n")
text_file.write(f"Greatest increase in profits:  {increase_month}  $({profit_increase}) \n")
text_file.write(f"Greatest decrease in profits:  {decrease_month}  $({profit_decrease})")

text_file.close()