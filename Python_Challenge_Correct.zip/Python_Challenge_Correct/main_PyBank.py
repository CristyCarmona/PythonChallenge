# Importar modulos para importrar y leer archivos cvs
import csv
import os 

# Definir el path para leer el archivo csv 
csvpath = os.path.join("Resources","budget_data.csv")

#Inicializacion de contadores 
row_counter = 0
row_sum = 0
profit_increase = 0
increase_month = "Ene-10" 
profit_decrease = 0
decrease_month = "Ene-10"
average_change_sum = 0


#Leer el archivo y obtener datos requeridos para la impresiond de la informacion requerida 
with open(csvpath,'r') as csvfile:
    
    csvreader = csv.reader(csvfile, delimiter = ",")
    
    # Obtener el header 
    header = next(csvreader) 
    primer_valor = 1
    
    if header != None: 
        for row in csvreader:
            row_counter += 1
            if primer_valor == 1:
                row_anterior = int(row[1])
                row_sum = int(row[1])
                primer_valor = 0 
            else:
                row_value = int(row[1])
                row_diference = row_value-row_anterior
                row_sum = row_sum + row_value
                average_change_sum = average_change_sum + row_diference
                row_anterior = row_value

                if row_diference > profit_increase:
                    profit_increase = row_diference
                    increase_month = row[0]
                elif row_diference < profit_decrease:
                    profit_decrease = row_diference
                    decrease_month = row[0]

# Promedio de los datos
meses_diferencia = row_counter-1
media = round(average_change_sum/meses_diferencia,2)

# Impresion de los datos 

print(f"Total months:  {row_counter}")
print(f"Total:  ${row_sum}")
print(f"Average change:  ${media}")
print(f"Greatest increase in profits:  {increase_month}  $({profit_increase})")
print(f"Greatest decrease in profits:  {decrease_month}  $({profit_decrease})")

#Crer un archivo de texto con los resulatdos 
text_file = open("Output_PyBank.txt", "w")

text_file.write(f"Total months:  {row_counter} \n")
text_file.write(f"Total:  ${row_sum} \n")
text_file.write(f"Average change:  ${media} \n")
text_file.write(f"Greatest increase in profits:  {increase_month}  $({profit_increase}) \n")
text_file.write(f"Greatest decrease in profits:  {decrease_month}  $({profit_decrease})")

text_file.close()